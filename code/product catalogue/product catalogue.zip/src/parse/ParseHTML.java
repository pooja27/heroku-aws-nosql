package parse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ParseHTML {
	public static void main(String[] args) {
		Document htmlFile = null;
		try {
			htmlFile = Jsoup.parse(new File("/home/pooja/281/Starbucks/documents/TeamProject/1.html"), "UTF-8");

			Elements div = htmlFile.getElementsByClass("product_card");
			System.out.println("Product Card Size: " + div.size());

			JSONArray array = new JSONArray();
			int count = 0;
			Random randomGenerator = new Random();

			BufferedWriter bw = new BufferedWriter(new FileWriter(new File("productCatalogueCoffee.json")));
			for (int i = 0; i < div.size(); i++) {
				JSONObject jsonObject = new JSONObject();

				Element productInfo = div.get(i);
				Elements d = productInfo.getElementsByClass("name");
				if (d.size() == 0)
					continue;
				Elements d1 = productInfo.getElementsByClass("product_info");
				Elements d2 = d1.get(0).getElementsByClass("product_name");
				System.out.println(d2.get(0).html());
				jsonObject.put("name", d2.get(0).html());
				jsonObject.put("category", "coffee");
				if(i%3==0) {
					jsonObject.put("price", 40);
					jsonObject.put("quantity", 5);
					jsonObject.put("type", "decaffinated");
					jsonObject.put("roast", "blonde");
					jsonObject.put("region", "latin america");
				}
				else if(i%5 == 0 ){
					jsonObject.put("price", 20);
					jsonObject.put("quantity", 3);
					jsonObject.put("type", "regular");
					jsonObject.put("roast", "dark");		
					jsonObject.put("region", "asia-pacific");
				}
				else {
					jsonObject.put("price", 50);
					jsonObject.put("quantity", 5);
					jsonObject.put("type", "regular");
					jsonObject.put("roast", "medium");	
					jsonObject.put("region", "multi");
				}
				jsonObject.put("flavor", "flavored");
				count++;				
				array.put(jsonObject);
			}
			bw.write(array.toString());
			System.out.println("count" + count);
			bw.close();
		} catch (IOException e) {
			// e.printStackTrace();
		} catch (IndexOutOfBoundsException ex) {

		}

	}

}
