package parse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ParseDrinkware {
	public static void main(String[] args) {
		Document htmlFile = null;
		try {
			htmlFile = Jsoup.parse(new File("/home/pooja/281/Starbucks/documents/TeamProject/drinkware.html"), "UTF-8");

			Elements div = htmlFile.getElementsByClass("product_card");
			System.out.println("Product Card Size: " + div.size());

			JSONArray array = new JSONArray();
			int count = 0;
			Random randomGenerator = new Random();

			BufferedWriter bw = new BufferedWriter(new FileWriter(new File("productCatalogueDrinkware.json")));
			for (int i = 0; i < div.size(); i++) {
				JSONObject jsonObject = new JSONObject();

				Element productInfo = div.get(i);
				Elements d = productInfo.getElementsByClass("name");
				if (d.size() == 0)
					continue;
				Elements d1 = productInfo.getElementsByClass("product_info");
				Elements d2 = d1.get(0).getElementsByClass("product_name");
				System.out.println(d2.get(0).html());
				jsonObject.put("name", d2.get(0).html());
				jsonObject.put("category", "drinkware");
				if(i%2==1) {
					jsonObject.put("price", 18.55);
				}
				else{
					jsonObject.put("price", 15.95);
				}
				
				count++;				
				array.put(jsonObject);
			}
			bw.write(array.toString());
			System.out.println("count" + count);
			bw.close();
		} catch (IOException e) {
			// e.printStackTrace();
		} catch (IndexOutOfBoundsException ex) {

		}

	}

}
